// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCSpeedButton.pas' rev: 5.00

#ifndef CCSpeedButtonHPP
#define CCSpeedButtonHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Menus.hpp>	// Pascal unit
#include <CCFlatUtils.hpp>	// Pascal unit
#include <ActnList.hpp>	// Pascal unit
#include <ImgList.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <Commctrl.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ccspeedbutton
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCCSpeedButton;
class PASCALIMPLEMENTATION TCCSpeedButton : public Controls::TGraphicControl 
{
	typedef Controls::TGraphicControl inherited;
	
private:
	Ccflatutils::TTransparentMode FTransparent;
	bool FUseAdvColors;
	Ccflatutils::TAdvColors FAdvColorFocused;
	Ccflatutils::TAdvColors FAdvColorDown;
	Ccflatutils::TAdvColors FAdvColorBorder;
	Windows::TRect TextBounds;
	Windows::TPoint GlyphPos;
	Ccflatutils::TNumGlyphs FNumGlyphs;
	Graphics::TColor FDownColor;
	Graphics::TColor FBorderColor;
	Graphics::TColor FColorHighlight;
	Graphics::TColor FColorShadow;
	Graphics::TColor FFocusedColor;
	int FGroupIndex;
	Graphics::TBitmap* FGlyph;
	bool FDown;
	bool FDragging;
	bool FAllowAllUp;
	Buttons::TButtonLayout FLayout;
	int FSpacing;
	int FMargin;
	bool FMouseInControl;
	Forms::TModalResult FModalResult;
	void __fastcall SetColors(int Index, Graphics::TColor Value);
	void __fastcall SetAdvColors(int Index, Ccflatutils::TAdvColors Value);
	void __fastcall SetUseAdvColors(bool Value);
	void __fastcall UpdateExclusive(void);
	void __fastcall SetGlyph(Graphics::TBitmap* Value);
	void __fastcall SetNumGlyphs(Ccflatutils::TNumGlyphs Value);
	void __fastcall SetDown(bool Value);
	void __fastcall SetAllowAllUp(bool Value);
	void __fastcall SetGroupIndex(int Value);
	void __fastcall SetLayout(Buttons::TButtonLayout Value);
	void __fastcall SetSpacing(int Value);
	void __fastcall SetMargin(int Value);
	void __fastcall UpdateTracking(void);
	HIDESBASE MESSAGE void __fastcall WMLButtonDblClk(Messages::TWMMouse &Message);
	HIDESBASE MESSAGE void __fastcall CMEnabledChanged(Messages::TMessage &Message);
	MESSAGE void __fastcall CMButtonPressed(Messages::TMessage &Message);
	MESSAGE void __fastcall CMDialogChar(Messages::TWMKey &Message);
	HIDESBASE MESSAGE void __fastcall CMFontChanged(Messages::TMessage &Message);
	MESSAGE void __fastcall CMTextChanged(Messages::TMessage &Message);
	MESSAGE void __fastcall CMSysColorChange(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMParentColorChanged(Messages::TWMNoParams &Message);
	void __fastcall SetTransparent(const Ccflatutils::TTransparentMode Value);
	void __fastcall RemoveMouseTimer(void);
	void __fastcall MouseTimerHandler(System::TObject* Sender);
	
protected:
	Buttons::TButtonState FState;
	DYNAMIC HPALETTE __fastcall GetPalette(void);
	void __fastcall CalcAdvColors(void);
	virtual void __fastcall Loaded(void);
	DYNAMIC void __fastcall MouseDown(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, 
		int Y);
	DYNAMIC void __fastcall MouseMove(Classes::TShiftState Shift, int X, int Y);
	DYNAMIC void __fastcall MouseUp(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int 
		Y);
	virtual void __fastcall Paint(void);
	DYNAMIC void __fastcall ActionChange(System::TObject* Sender, bool CheckDefaults);
	
public:
	__fastcall virtual TCCSpeedButton(Classes::TComponent* AOwner);
	__fastcall virtual ~TCCSpeedButton(void);
	DYNAMIC void __fastcall Click(void);
	void __fastcall MouseEnter(void);
	void __fastcall MouseLeave(void);
	
__published:
	__property Ccflatutils::TTransparentMode TransparentMode = {read=FTransparent, write=SetTransparent
		, default=2};
	__property bool AllowAllUp = {read=FAllowAllUp, write=SetAllowAllUp, default=0};
	__property Color ;
	__property Graphics::TColor ColorFocused = {read=FFocusedColor, write=SetColors, index=0, default=14805739
		};
	__property Graphics::TColor ColorDown = {read=FDownColor, write=SetColors, index=1, default=12965593
		};
	__property Graphics::TColor ColorBorder = {read=FBorderColor, write=SetColors, index=2, default=8623776
		};
	__property Graphics::TColor ColorHighLight = {read=FColorHighlight, write=SetColors, index=3, default=16777215
		};
	__property Graphics::TColor ColorShadow = {read=FColorShadow, write=SetColors, index=4, default=0};
		
	__property Ccflatutils::TAdvColors AdvColorFocused = {read=FAdvColorFocused, write=SetAdvColors, index=0
		, default=10};
	__property Ccflatutils::TAdvColors AdvColorDown = {read=FAdvColorDown, write=SetAdvColors, index=1, 
		default=10};
	__property Ccflatutils::TAdvColors AdvColorBorder = {read=FAdvColorBorder, write=SetAdvColors, index=2
		, default=50};
	__property bool UseAdvColors = {read=FUseAdvColors, write=SetUseAdvColors, default=0};
	__property int GroupIndex = {read=FGroupIndex, write=SetGroupIndex, default=0};
	__property bool Down = {read=FDown, write=SetDown, default=0};
	__property Caption ;
	__property Enabled ;
	__property Font ;
	__property Graphics::TBitmap* Glyph = {read=FGlyph, write=SetGlyph};
	__property Buttons::TButtonLayout Layout = {read=FLayout, write=SetLayout, default=2};
	__property int Margin = {read=FMargin, write=SetMargin, default=-1};
	__property Ccflatutils::TNumGlyphs NumGlyphs = {read=FNumGlyphs, write=SetNumGlyphs, default=1};
	__property Forms::TModalResult ModalResult = {read=FModalResult, write=FModalResult, default=0};
	__property ParentFont ;
	__property ParentColor ;
	__property ParentShowHint ;
	__property PopupMenu ;
	__property ShowHint ;
	__property int Spacing = {read=FSpacing, write=SetSpacing, default=4};
	__property Visible ;
	__property OnClick ;
	__property OnDblClick ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property Action ;
	__property Anchors ;
	__property BiDiMode ;
	__property Constraints ;
	__property DragKind ;
	__property ParentBiDiMode ;
	__property OnEndDock ;
	__property OnStartDock ;
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCCSpeedButton* MouseInControl;

}	/* namespace Ccspeedbutton */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Ccspeedbutton;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCSpeedButton
