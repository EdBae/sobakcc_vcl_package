//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("sobakcc_c5.res");
USEPACKAGE("vcl50.bpi");
USEUNIT("CCAboutbox.pas");
USEFORMNS("CCAboutboxForm.pas", Ccaboutboxform, AboutWnd);
USEUNIT("CCAlignEdit.pas");
USEUNIT("CCAnimation.pas");
USEUNIT("CCAnimWnd.pas");
USEUNIT("CCButton.pas");
USEUNIT("CCCheckBox.pas");
USEUNIT("CCCheckListBox.pas");
USEUNIT("CCColorComboBox.pas");
USEUNIT("CCComboBox.pas");
USEUNIT("CCDBComboBox.pas");
USEUNIT("CCDBEdit.pas");
USEUNIT("CCDBLookupComboBox.pas");
USEUNIT("CCDBMemo.pas");
USEUNIT("CCEdit.pas");
USEUNIT("CCFlatGraphics.pas");
USEUNIT("CCFlatUtils.pas");
USEUNIT("CCGauge.pas");
USEUNIT("CCGroupBox.pas");
USEUNIT("CCHint.pas");
USEUNIT("CCHSLUtils.pas");
USEUNIT("CCLinkText.pas");
USEUNIT("CCListBox.pas");
USEUNIT("CCMaskEdit.pas");
USEUNIT("CCMemo.pas");
USEUNIT("CCPanel.pas");
USEUNIT("CCProgressBar.pas");
USEUNIT("CCRadioButton.pas");
USEUNIT("CCShape.pas");
USEUNIT("CCSound.pas");
USEUNIT("CCSpeedButton.pas");
USEUNIT("CCSpinButton.pas");
USEUNIT("CCSpinEdit.pas");
USEUNIT("CCSplitter.pas");
USEUNIT("CCTabControl.pas");
USEUNIT("Sobakcc_Register.pas");
USEPACKAGE("vcljpg50.bpi");
USEPACKAGE("Vcldb50.bpi");
USERES("sobakcc_d5.dcr");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
return 1;
}
//---------------------------------------------------------------------------
