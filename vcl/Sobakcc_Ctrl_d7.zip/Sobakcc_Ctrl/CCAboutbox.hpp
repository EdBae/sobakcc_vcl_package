// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCAboutbox.pas' rev: 5.00

#ifndef CCAboutboxHPP
#define CCAboutboxHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ccaboutbox
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCCAboutbox;
class PASCALIMPLEMENTATION TCCAboutbox : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	AnsiString FAppName;
	AnsiString FCopyright;
	AnsiString FEMail;
	AnsiString FSerialNo;
	bool FShowlicense;
	AnsiString FUrl;
	AnsiString FUserName;
	bool __fastcall IsCopyrightStored(void);
	bool __fastcall IsUrlStored(void);
	bool __fastcall IsEMailStored(void);
	
public:
	__fastcall virtual TCCAboutbox(Classes::TComponent* AOwner);
	__fastcall virtual ~TCCAboutbox(void);
	void __fastcall Execute(void);
	
__published:
	__property AnsiString AppName = {read=FAppName, write=FAppName};
	__property AnsiString Copyright = {read=FCopyright, write=FCopyright, stored=IsCopyrightStored};
	__property AnsiString EMail = {read=FEMail, write=FEMail, stored=IsEMailStored};
	__property AnsiString SerialNo = {read=FSerialNo, write=FSerialNo};
	__property bool Showlicense = {read=FShowlicense, write=FShowlicense, default=1};
	__property AnsiString Url = {read=FUrl, write=FUrl, stored=IsUrlStored};
	__property AnsiString UserName = {read=FUserName, write=FUserName};
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE System::ResourceString _SErrorOpenSysInfo;
#define Ccaboutbox_SErrorOpenSysInfo System::LoadResourceString(&Ccaboutbox::_SErrorOpenSysInfo)
extern PACKAGE System::ResourceString _SAboutBuildNo;
#define Ccaboutbox_SAboutBuildNo System::LoadResourceString(&Ccaboutbox::_SAboutBuildNo)
extern PACKAGE System::ResourceString _SCopyright;
#define Ccaboutbox_SCopyright System::LoadResourceString(&Ccaboutbox::_SCopyright)
#define SDefaultUrl "http://www.sobakcc.com"
#define SDefaultEMail "sobakcc@drreamwiz.com"

}	/* namespace Ccaboutbox */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Ccaboutbox;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCAboutbox
