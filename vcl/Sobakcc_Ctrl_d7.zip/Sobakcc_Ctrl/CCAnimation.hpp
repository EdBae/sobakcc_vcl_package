// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCAnimation.pas' rev: 5.00

#ifndef CCAnimationHPP
#define CCAnimationHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <CCFlatUtils.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ccanimation
{
//-- type declarations -------------------------------------------------------
typedef void __fastcall (__closure *TOnFrameChange)(System::TObject* Sender, int FrameNumber);

#pragma option push -b-
enum TAnimOrientation { rows, cols };
#pragma option pop

class DELPHICLASS TCCAnimation;
class PASCALIMPLEMENTATION TCCAnimation : public Controls::TGraphicControl 
{
	typedef Controls::TGraphicControl inherited;
	
private:
	bool FUseAdvColors;
	Ccflatutils::TAdvColors FAdvColorHighlight;
	Ccflatutils::TAdvColors FAdvColorShadow;
	bool FTransparent;
	Graphics::TBitmap* FAnimation;
	int FFrames;
	int FFrameWidth;
	int FFrame;
	int FInterval;
	Graphics::TColor FTransColor;
	bool FActive;
	bool FLoop;
	bool FReverse;
	Extctrls::TTimer* FTimer;
	Graphics::TColor FHighlightColor;
	Graphics::TColor FShadowColor;
	bool FBorder;
	TOnFrameChange FFrameChange;
	TAnimOrientation FOrientation;
	void __fastcall SetAnimation(Graphics::TBitmap* Value);
	void __fastcall SetFrames(int Value);
	void __fastcall SetFrameWidth(int Value);
	void __fastcall SetFrame(int Value);
	void __fastcall SetActive(bool Value);
	void __fastcall SetTransparent(bool Value);
	void __fastcall SetLoop(bool Value);
	void __fastcall SetReverse(bool Value);
	void __fastcall SetInterval(int Value);
	void __fastcall SetBorder(bool Value);
	void __fastcall DoTimer(System::TObject* Sender);
	void __fastcall SetColors(int Index, Graphics::TColor Value);
	void __fastcall SetAdvColors(int Index, Ccflatutils::TAdvColors Value);
	void __fastcall SetUseAdvColors(bool Value);
	MESSAGE void __fastcall CMSysColorChange(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMParentColorChanged(Messages::TWMNoParams &Message);
	MESSAGE void __fastcall WMSize(Messages::TWMSize &Message);
	void __fastcall SetOrientation(const TAnimOrientation Value);
	
protected:
	virtual void __fastcall Paint(void);
	void __fastcall CalcAdvColors(void);
	
public:
	__fastcall virtual TCCAnimation(Classes::TComponent* AOwner);
	__fastcall virtual ~TCCAnimation(void);
	
__published:
	__property Ccflatutils::TAdvColors AdvColorHighlight = {read=FAdvColorHighlight, write=SetAdvColors
		, index=0, default=50};
	__property Ccflatutils::TAdvColors AdvColorShadow = {read=FAdvColorShadow, write=SetAdvColors, index=1
		, default=50};
	__property bool UseAdvColors = {read=FUseAdvColors, write=SetUseAdvColors, default=0};
	__property Color ;
	__property Graphics::TBitmap* Animation = {read=FAnimation, write=SetAnimation};
	__property int Frames = {read=FFrames, write=SetFrames, nodefault};
	__property int FrameWidth = {read=FFrameWidth, write=SetFrameWidth, nodefault};
	__property int Frame = {read=FFrame, write=SetFrame, default=1};
	__property int Interval = {read=FInterval, write=SetInterval, nodefault};
	__property Graphics::TColor ColorTransparent = {read=FTransColor, write=SetColors, index=0, default=16711935
		};
	__property Graphics::TColor ColorHighLight = {read=FHighlightColor, write=SetColors, index=1, nodefault
		};
	__property Graphics::TColor ColorShadow = {read=FShadowColor, write=SetColors, index=2, nodefault};
		
	__property bool Active = {read=FActive, write=SetActive, nodefault};
	__property bool Loop = {read=FLoop, write=SetLoop, nodefault};
	__property bool Reverse = {read=FReverse, write=SetReverse, nodefault};
	__property bool Border = {read=FBorder, write=SetBorder, nodefault};
	__property TAnimOrientation Orientation = {read=FOrientation, write=SetOrientation, nodefault};
	__property TOnFrameChange OnFrameChange = {read=FFrameChange, write=FFrameChange};
	__property bool Transparent = {read=FTransparent, write=SetTransparent, nodefault};
	__property Align ;
	__property Enabled ;
	__property ParentColor ;
	__property ParentShowHint ;
	__property ShowHint ;
	__property Visible ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnEndDrag ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property OnStartDrag ;
	__property Anchors ;
	__property BiDiMode ;
	__property Constraints ;
	__property DragKind ;
	__property ParentBiDiMode ;
	__property OnEndDock ;
	__property OnStartDock ;
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Ccanimation */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Ccanimation;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCAnimation
