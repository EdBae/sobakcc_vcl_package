// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCDBComboBox.pas' rev: 5.00

#ifndef CCDBComboBoxHPP
#define CCDBComboBoxHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Menus.hpp>	// Pascal unit
#include <CCFlatUtils.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <Commctrl.hpp>	// Pascal unit
#include <DBCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ccdbcombobox
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCCDBComboBox;
class PASCALIMPLEMENTATION TCCDBComboBox : public Dbctrls::TDBComboBox 
{
	typedef Dbctrls::TDBComboBox inherited;
	
private:
	Graphics::TColor FArrowColor;
	Graphics::TColor FArrowBackgroundColor;
	Graphics::TColor FBorderColor;
	int FButtonWidth;
	HWND FChildHandle;
	void *FDefListProc;
	HWND FListHandle;
	void *FListInstance;
	int FSysBtnWidth;
	bool FSolidBorder;
	void __fastcall SetColors(int Index, Graphics::TColor Value);
	Windows::TRect __fastcall GetButtonRect();
	void __fastcall PaintButton(void);
	void __fastcall PaintBorder(void);
	void __fastcall RedrawBorders(void);
	void __fastcall InvalidateSelection(void);
	bool __fastcall GetSolidBorder(void);
	void __fastcall SetSolidBorder(void);
	HIDESBASE void __fastcall ListWndProc(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall WMSetFocus(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall WMKillFocus(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall WMKeyDown(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall WMPaint(Messages::TWMPaint &Message);
	HIDESBASE MESSAGE void __fastcall WMNCPaint(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMEnabledChanged(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall CNCommand(Messages::TWMCommand &Message);
	HIDESBASE MESSAGE void __fastcall CMFontChanged(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMSysColorChange(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMParentColorChanged(Messages::TWMNoParams &Message);
	
protected:
	virtual void __fastcall WndProc(Messages::TMessage &Message);
	virtual void __fastcall ComboWndProc(Messages::TMessage &Message, HWND ComboWnd, void * ComboProc);
		
	__property bool SolidBorder = {read=FSolidBorder, nodefault};
	
public:
	__fastcall virtual TCCDBComboBox(Classes::TComponent* AOwner);
	__fastcall virtual ~TCCDBComboBox(void);
	
__published:
	__property Style ;
	__property Color ;
	__property Graphics::TColor ColorArrow = {read=FArrowColor, write=SetColors, index=0, default=0};
	__property Graphics::TColor ColorArrowBackground = {read=FArrowBackgroundColor, write=SetColors, index=1
		, default=12965593};
	__property Graphics::TColor ColorBorder = {read=FBorderColor, write=SetColors, index=2, default=8623776
		};
	__property DragMode ;
	__property DragCursor ;
	__property DropDownCount ;
	__property Enabled ;
	__property Font ;
	__property ItemHeight ;
	__property Items ;
	__property MaxLength ;
	__property ParentFont ;
	__property ParentShowHint ;
	__property PopupMenu ;
	__property ShowHint ;
	__property Sorted ;
	__property TabOrder ;
	__property TabStop ;
	__property Text ;
	__property Visible ;
	__property ItemIndex ;
	__property OnChange ;
	__property OnClick ;
	__property OnDblClick ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnDrawItem ;
	__property OnDropDown ;
	__property OnEndDrag ;
	__property OnEnter ;
	__property OnExit ;
	__property OnKeyDown ;
	__property OnKeyPress ;
	__property OnKeyUp ;
	__property OnMeasureItem ;
	__property OnStartDrag ;
	__property Anchors ;
	__property BiDiMode ;
	__property Constraints ;
	__property DragKind ;
	__property ParentBiDiMode ;
	__property OnEndDock ;
	__property OnStartDock ;
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCCDBComboBox(HWND ParentWindow) : Dbctrls::TDBComboBox(
		ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Ccdbcombobox */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Ccdbcombobox;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCDBComboBox
