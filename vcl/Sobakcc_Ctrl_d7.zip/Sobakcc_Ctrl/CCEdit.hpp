// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCEdit.pas' rev: 5.00

#ifndef CCEditHPP
#define CCEditHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Menus.hpp>	// Pascal unit
#include <CCFlatUtils.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ccedit
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCCCustomEdit;
class PASCALIMPLEMENTATION TCCCustomEdit : public Stdctrls::TCustomEdit 
{
	typedef Stdctrls::TCustomEdit inherited;
	
private:
	Classes::TAlignment FAlignment;
	bool FUseAdvColors;
	Ccflatutils::TAdvColors FAdvColorFocused;
	Ccflatutils::TAdvColors FAdvColorBorder;
	bool FParentColor;
	Graphics::TColor FFocusedColor;
	Graphics::TColor FBorderColor;
	Graphics::TColor FFlatColor;
	bool MouseInControl;
	void __fastcall SetAlignment(const Classes::TAlignment Value);
	void __fastcall SetColors(int Index, Graphics::TColor Value);
	void __fastcall SetAdvColors(int Index, Ccflatutils::TAdvColors Value);
	void __fastcall SetUseAdvColors(bool Value);
	HIDESBASE void __fastcall SetParentColor(bool Value);
	void __fastcall RedrawBorder(const HRGN Clip);
	void __fastcall NewAdjustHeight(void);
	HIDESBASE MESSAGE void __fastcall CMEnabledChanged(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMFontChanged(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMMouseEnter(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMMouseLeave(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall WMSetFocus(Messages::TWMSetFocus &Message);
	HIDESBASE MESSAGE void __fastcall WMKillFocus(Messages::TWMKillFocus &Message);
	HIDESBASE MESSAGE void __fastcall WMNCCalcSize(Messages::TWMNCCalcSize &Message);
	HIDESBASE MESSAGE void __fastcall WMNCPaint(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMSysColorChange(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMParentColorChanged(Messages::TWMNoParams &Message);
	
protected:
	virtual void __fastcall CreateParams(Controls::TCreateParams &Params);
	void __fastcall CalcAdvColors(void);
	virtual void __fastcall Loaded(void);
	__property Graphics::TColor ColorFocused = {read=FFocusedColor, write=SetColors, index=0, default=16777215
		};
	__property Graphics::TColor ColorBorder = {read=FBorderColor, write=SetColors, index=1, default=8623776
		};
	__property Graphics::TColor ColorFlat = {read=FFlatColor, write=SetColors, index=2, default=14805739
		};
	__property bool ParentColor = {read=FParentColor, write=SetParentColor, default=0};
	__property Ccflatutils::TAdvColors AdvColorFocused = {read=FAdvColorFocused, write=SetAdvColors, index=0
		, default=10};
	__property Ccflatutils::TAdvColors AdvColorBorder = {read=FAdvColorBorder, write=SetAdvColors, index=1
		, default=50};
	__property bool UseAdvColors = {read=FUseAdvColors, write=SetUseAdvColors, default=0};
	__property CharCase ;
	__property DragCursor ;
	__property DragMode ;
	__property Enabled ;
	__property Font ;
	__property HideSelection ;
	__property MaxLength ;
	__property OEMConvert ;
	__property ParentFont ;
	__property ParentShowHint ;
	__property PasswordChar ;
	__property PopupMenu ;
	__property ReadOnly ;
	__property ShowHint ;
	__property TabOrder ;
	__property TabStop ;
	__property Text ;
	__property Visible ;
	__property OnChange ;
	__property OnClick ;
	__property OnDblClick ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnEndDrag ;
	__property OnEnter ;
	__property OnExit ;
	__property OnKeyDown ;
	__property OnKeyPress ;
	__property OnKeyUp ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property OnStartDrag ;
	__property Anchors ;
	__property BiDiMode ;
	__property Constraints ;
	__property DragKind ;
	__property ParentBiDiMode ;
	__property OnEndDock ;
	__property OnStartDock ;
	
public:
	__fastcall virtual TCCCustomEdit(Classes::TComponent* AOwner);
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCCCustomEdit(HWND ParentWindow) : Stdctrls::TCustomEdit(
		ParentWindow) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TWinControl.Destroy */ inline __fastcall virtual ~TCCCustomEdit(void) { }
	#pragma option pop
	
};


class DELPHICLASS TCCEdit;
class PASCALIMPLEMENTATION TCCEdit : public TCCCustomEdit 
{
	typedef TCCCustomEdit inherited;
	
__published:
	__property Classes::TAlignment Alignment = {read=FAlignment, write=SetAlignment, default=0};
	__property Graphics::TColor ColorFocused = {read=FFocusedColor, write=SetColors, index=0, default=16777215
		};
	__property Graphics::TColor ColorBorder = {read=FBorderColor, write=SetColors, index=1, default=8623776
		};
	__property Graphics::TColor ColorFlat = {read=FFlatColor, write=SetColors, index=2, default=14805739
		};
	__property bool ParentColor = {read=FParentColor, write=SetParentColor, default=0};
	__property Ccflatutils::TAdvColors AdvColorFocused = {read=FAdvColorFocused, write=SetAdvColors, index=0
		, default=10};
	__property Ccflatutils::TAdvColors AdvColorBorder = {read=FAdvColorBorder, write=SetAdvColors, index=1
		, default=50};
	__property bool UseAdvColors = {read=FUseAdvColors, write=SetUseAdvColors, default=0};
	__property CharCase ;
	__property DragCursor ;
	__property DragMode ;
	__property Enabled ;
	__property Font ;
	__property HideSelection ;
	__property MaxLength ;
	__property OEMConvert ;
	__property ParentFont ;
	__property ParentShowHint ;
	__property PasswordChar ;
	__property PopupMenu ;
	__property ReadOnly ;
	__property ShowHint ;
	__property TabOrder ;
	__property TabStop ;
	__property Text ;
	__property Visible ;
	__property OnChange ;
	__property OnClick ;
	__property OnDblClick ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnEndDrag ;
	__property OnEnter ;
	__property OnExit ;
	__property OnKeyDown ;
	__property OnKeyPress ;
	__property OnKeyUp ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property OnStartDrag ;
	__property Anchors ;
	__property BiDiMode ;
	__property Constraints ;
	__property DragKind ;
	__property ParentBiDiMode ;
	__property OnEndDock ;
	__property OnStartDock ;
public:
	#pragma option push -w-inl
	/* TCCCustomEdit.Create */ inline __fastcall virtual TCCEdit(Classes::TComponent* AOwner) : TCCCustomEdit(
		AOwner) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCCEdit(HWND ParentWindow) : TCCCustomEdit(ParentWindow
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TWinControl.Destroy */ inline __fastcall virtual ~TCCEdit(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE int Alignments[3];

}	/* namespace Ccedit */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Ccedit;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCEdit
