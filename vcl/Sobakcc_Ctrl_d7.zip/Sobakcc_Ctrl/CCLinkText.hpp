// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCLinkText.pas' rev: 5.00

#ifndef CCLinkTextHPP
#define CCLinkTextHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <ShellAPI.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Cclinktext
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TMouseOver { moNone, moUnderline, moHandPoint, moBoth };
#pragma option pop

class DELPHICLASS TCCLinkText;
class PASCALIMPLEMENTATION TCCLinkText : public Stdctrls::TStaticText 
{
	typedef Stdctrls::TStaticText inherited;
	
private:
	TMouseOver FMouseOver;
	void __fastcall DoClick(System::TObject* Sender);
	
public:
	__fastcall virtual TCCLinkText(Classes::TComponent* AOwner);
	HIDESBASE MESSAGE void __fastcall CMMOUSEENTER(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall CMMOUSELEAVE(Messages::TMessage &Msg);
	
__published:
	__property TMouseOver MouseOver = {read=FMouseOver, write=FMouseOver, nodefault};
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCCLinkText(HWND ParentWindow) : Stdctrls::TStaticText(
		ParentWindow) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TWinControl.Destroy */ inline __fastcall virtual ~TCCLinkText(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Cclinktext */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Cclinktext;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCLinkText
