// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCProgressBar.pas' rev: 5.00

#ifndef CCProgressBarHPP
#define CCProgressBarHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Menus.hpp>	// Pascal unit
#include <CCFlatUtils.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ccprogressbar
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCCProgressBar;
class PASCALIMPLEMENTATION TCCProgressBar : public Controls::TGraphicControl 
{
	typedef Controls::TGraphicControl inherited;
	
private:
	bool FTransparent;
	bool FSmooth;
	bool FUseAdvColors;
	Ccflatutils::TAdvColors FAdvColorBorder;
	Comctrls::TProgressBarOrientation FOrientation;
	int FElementWidth;
	Graphics::TColor FElementColor;
	Graphics::TColor FBorderColor;
	int FPosition;
	int FMin;
	int FMax;
	int FStep;
	void __fastcall SetMin(int Value);
	void __fastcall SetMax(int Value);
	void __fastcall SetPosition(int Value);
	void __fastcall SetStep(int Value);
	void __fastcall SetColors(int Index, Graphics::TColor Value);
	void __fastcall SetAdvColors(int Index, Ccflatutils::TAdvColors Value);
	void __fastcall SetUseAdvColors(bool Value);
	void __fastcall SetOrientation(Comctrls::TProgressBarOrientation Value);
	void __fastcall SetSmooth(bool Value);
	void __fastcall CheckBounds(void);
	MESSAGE void __fastcall CMSysColorChange(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMParentColorChanged(Messages::TWMNoParams &Message);
	void __fastcall SetTransparent(const bool Value);
	
protected:
	void __fastcall CalcAdvColors(void);
	void __fastcall DrawElements(void);
	virtual void __fastcall Paint(void);
	
public:
	__fastcall virtual TCCProgressBar(Classes::TComponent* AOwner);
	void __fastcall StepIt(void);
	void __fastcall StepBy(int Delta);
	
__published:
	__property bool Transparent = {read=FTransparent, write=SetTransparent, default=0};
	__property Align ;
	__property Cursor ;
	__property Color ;
	__property Graphics::TColor ColorElement = {read=FElementColor, write=SetColors, index=0, default=10053171
		};
	__property Graphics::TColor ColorBorder = {read=FBorderColor, write=SetColors, index=1, default=8623776
		};
	__property Ccflatutils::TAdvColors AdvColorBorder = {read=FAdvColorBorder, write=SetAdvColors, index=0
		, default=50};
	__property bool UseAdvColors = {read=FUseAdvColors, write=SetUseAdvColors, default=0};
	__property Comctrls::TProgressBarOrientation Orientation = {read=FOrientation, write=SetOrientation
		, default=0};
	__property Enabled ;
	__property ParentColor ;
	__property Visible ;
	__property Hint ;
	__property ShowHint ;
	__property PopupMenu ;
	__property ParentShowHint ;
	__property int Min = {read=FMin, write=SetMin, nodefault};
	__property int Max = {read=FMax, write=SetMax, nodefault};
	__property int Position = {read=FPosition, write=SetPosition, default=0};
	__property int Step = {read=FStep, write=SetStep, default=10};
	__property bool Smooth = {read=FSmooth, write=SetSmooth, default=0};
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnEndDrag ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property OnStartDrag ;
	__property Anchors ;
	__property BiDiMode ;
	__property Constraints ;
	__property DragKind ;
	__property ParentBiDiMode ;
	__property OnEndDock ;
	__property OnStartDock ;
public:
	#pragma option push -w-inl
	/* TGraphicControl.Destroy */ inline __fastcall virtual ~TCCProgressBar(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Ccprogressbar */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Ccprogressbar;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCProgressBar
