// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCMaskEdit.pas' rev: 5.00

#ifndef CCMaskEditHPP
#define CCMaskEditHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Menus.hpp>	// Pascal unit
#include <Mask.hpp>	// Pascal unit
#include <CCFlatUtils.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ccmaskedit
{
//-- type declarations -------------------------------------------------------
typedef void __fastcall (__closure *TValidateEvent)(System::TObject* Sender);

class DELPHICLASS TCCMaskEdit;
class PASCALIMPLEMENTATION TCCMaskEdit : public Mask::TCustomMaskEdit 
{
	typedef Mask::TCustomMaskEdit inherited;
	
private:
	bool FUseAdvColors;
	Ccflatutils::TAdvColors FAdvColorFocused;
	Ccflatutils::TAdvColors FAdvColorBorder;
	bool FParentColor;
	Graphics::TColor FFocusedColor;
	Graphics::TColor FBorderColor;
	Graphics::TColor FFlatColor;
	TValidateEvent FOnValidate;
	bool MouseInControl;
	void __fastcall SetColors(int Index, Graphics::TColor Value);
	void __fastcall SetAdvColors(int Index, Ccflatutils::TAdvColors Value);
	void __fastcall SetUseAdvColors(bool Value);
	HIDESBASE void __fastcall SetParentColor(bool Value);
	void __fastcall RedrawBorder(const HRGN Clip);
	void __fastcall NewAdjustHeight(void);
	HIDESBASE MESSAGE void __fastcall CMEnabledChanged(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMFontChanged(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMMouseEnter(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMMouseLeave(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall WMSetFocus(Messages::TWMSetFocus &Message);
	HIDESBASE MESSAGE void __fastcall WMKillFocus(Messages::TWMKillFocus &Message);
	HIDESBASE MESSAGE void __fastcall WMNCCalcSize(Messages::TWMNCCalcSize &Message);
	HIDESBASE MESSAGE void __fastcall WMNCPaint(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMSysColorChange(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMParentColorChanged(Messages::TWMNoParams &Message);
	
protected:
	void __fastcall CalcAdvColors(void);
	virtual void __fastcall Loaded(void);
	
public:
	__fastcall virtual TCCMaskEdit(Classes::TComponent* AOwner);
	virtual void __fastcall ValidateEdit(void);
	
__published:
	__property Graphics::TColor ColorFocused = {read=FFocusedColor, write=SetColors, index=0, default=16777215
		};
	__property Graphics::TColor ColorBorder = {read=FBorderColor, write=SetColors, index=1, default=8623776
		};
	__property Graphics::TColor ColorFlat = {read=FFlatColor, write=SetColors, index=2, default=14805739
		};
	__property bool ParentColor = {read=FParentColor, write=SetParentColor, default=0};
	__property Ccflatutils::TAdvColors AdvColorFocused = {read=FAdvColorFocused, write=SetAdvColors, index=0
		, default=10};
	__property Ccflatutils::TAdvColors AdvColorBorder = {read=FAdvColorBorder, write=SetAdvColors, index=1
		, default=50};
	__property bool UseAdvColors = {read=FUseAdvColors, write=SetUseAdvColors, default=0};
	__property Align ;
	__property AutoSelect ;
	__property AutoSize ;
	__property BorderStyle ;
	__property CharCase ;
	__property Color ;
	__property Ctl3D ;
	__property DragCursor ;
	__property DragMode ;
	__property Enabled ;
	__property EditMask ;
	__property Font ;
	__property HideSelection ;
	__property MaxLength ;
	__property OEMConvert ;
	__property ParentCtl3D ;
	__property ParentFont ;
	__property ParentShowHint ;
	__property PasswordChar ;
	__property PopupMenu ;
	__property ReadOnly ;
	__property ShowHint ;
	__property TabOrder ;
	__property TabStop ;
	__property Text ;
	__property Visible ;
	__property OnChange ;
	__property OnClick ;
	__property OnDblClick ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnEndDrag ;
	__property OnEnter ;
	__property OnExit ;
	__property OnKeyDown ;
	__property OnKeyPress ;
	__property OnKeyUp ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property OnStartDrag ;
	__property TValidateEvent OnValidate = {read=FOnValidate, write=FOnValidate};
	__property ImeMode ;
	__property ImeName ;
	__property Anchors ;
	__property BiDiMode ;
	__property Constraints ;
	__property DragKind ;
	__property ParentBiDiMode ;
	__property OnEndDock ;
	__property OnStartDock ;
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCCMaskEdit(HWND ParentWindow) : Mask::TCustomMaskEdit(
		ParentWindow) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TWinControl.Destroy */ inline __fastcall virtual ~TCCMaskEdit(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Ccmaskedit */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Ccmaskedit;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCMaskEdit
