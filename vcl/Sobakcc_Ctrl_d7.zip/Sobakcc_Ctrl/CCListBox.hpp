// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCListBox.pas' rev: 5.00

#ifndef CCListBoxHPP
#define CCListBoxHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Menus.hpp>	// Pascal unit
#include <CCFlatUtils.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Cclistbox
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCCListBox;
class PASCALIMPLEMENTATION TCCListBox : public Controls::TCustomControl 
{
	typedef Controls::TCustomControl inherited;
	
private:
	Ccflatutils::TTransparentMode FTransparent;
	unsigned cWheelMessage;
	Ccflatutils::TScrollType scrollType;
	int firstItem;
	int maxItems;
	bool FSorted;
	Classes::TStringList* FItems;
	Classes::TList* FItemsRect;
	int FItemsHeight;
	System::Set<Byte, 0, 255>  FSelected;
	bool FMultiSelect;
	bool FScrollBars;
	bool FUseAdvColors;
	Ccflatutils::TAdvColors FAdvColorBorder;
	Graphics::TColor FArrowColor;
	Graphics::TColor FBorderColor;
	Graphics::TColor FItemsRectColor;
	Graphics::TColor FItemsSelectColor;
	void __fastcall SetColors(int Index, Graphics::TColor Value);
	void __fastcall SetAdvColors(int Index, Ccflatutils::TAdvColors Value);
	void __fastcall SetUseAdvColors(bool Value);
	void __fastcall SetSorted(bool Value);
	void __fastcall SetItems(Classes::TStringList* Value);
	void __fastcall SetItemsRect(void);
	void __fastcall SetItemsHeight(int Value);
	bool __fastcall GetSelected(int Index);
	void __fastcall SetSelected(int Index, bool Value);
	int __fastcall GetSelCount(void);
	void __fastcall SetScrollBars(bool Value);
	HIDESBASE MESSAGE void __fastcall WMSize(Messages::TWMSize &Message);
	HIDESBASE MESSAGE void __fastcall CMEnabledChanged(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMSysColorChange(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMParentColorChanged(Messages::TWMNoParams &Message);
	void __fastcall ScrollTimerHandler(System::TObject* Sender);
	void __fastcall ItemsChanged(System::TObject* Sender);
	HIDESBASE MESSAGE void __fastcall WMMove(Messages::TWMMove &Message);
	HIDESBASE MESSAGE void __fastcall WMSetFocus(Messages::TWMSetFocus &Message);
	HIDESBASE MESSAGE void __fastcall WMKillFocus(Messages::TWMKillFocus &Message);
	HIDESBASE MESSAGE void __fastcall CNKeyDown(Messages::TWMKey &Message);
	void __fastcall SetTransparent(const Ccflatutils::TTransparentMode Value);
	HIDESBASE MESSAGE void __fastcall WMMouseWheel(Messages::TMessage &Message);
	
protected:
	void __fastcall CalcAdvColors(void);
	void __fastcall DrawScrollBar(Graphics::TCanvas* canvas);
	virtual void __fastcall Paint(void);
	virtual void __fastcall Loaded(void);
	DYNAMIC void __fastcall MouseDown(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, 
		int Y);
	DYNAMIC void __fastcall MouseUp(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int 
		Y);
	virtual void __fastcall WndProc(Messages::TMessage &Message);
	
public:
	__fastcall virtual TCCListBox(Classes::TComponent* AOwner);
	__fastcall virtual ~TCCListBox(void);
	__property bool Selected[int Index] = {read=GetSelected, write=SetSelected};
	__property int SelCount = {read=GetSelCount, nodefault};
	
__published:
	__property Ccflatutils::TTransparentMode TransparentMode = {read=FTransparent, write=SetTransparent
		, default=2};
	__property Align ;
	__property Classes::TStringList* Items = {read=FItems, write=SetItems};
	__property int ItemHeight = {read=FItemsHeight, write=SetItemsHeight, default=17};
	__property bool MultiSelect = {read=FMultiSelect, write=FMultiSelect, default=0};
	__property bool ScrollBars = {read=FScrollBars, write=SetScrollBars, default=0};
	__property Color ;
	__property Graphics::TColor ColorArrow = {read=FArrowColor, write=SetColors, index=0, default=0};
	__property Graphics::TColor ColorBorder = {read=FBorderColor, write=SetColors, index=1, default=8623776
		};
	__property Graphics::TColor ColorItemsRect = {read=FItemsRectColor, write=SetColors, index=2, default=16777215
		};
	__property Graphics::TColor ColorItemsSelect = {read=FItemsSelectColor, write=SetColors, index=3, default=10280695
		};
	__property Ccflatutils::TAdvColors AdvColorBorder = {read=FAdvColorBorder, write=SetAdvColors, index=0
		, default=40};
	__property bool UseAdvColors = {read=FUseAdvColors, write=SetUseAdvColors, default=0};
	__property bool Sorted = {read=FSorted, write=SetSorted, default=0};
	__property Font ;
	__property ParentFont ;
	__property ParentColor ;
	__property ParentShowHint ;
	__property Enabled ;
	__property Visible ;
	__property PopupMenu ;
	__property ShowHint ;
	__property OnClick ;
	__property OnMouseMove ;
	__property OnMouseDown ;
	__property OnMouseUp ;
	__property Anchors ;
	__property BiDiMode ;
	__property Constraints ;
	__property DragKind ;
	__property ParentBiDiMode ;
	__property OnEndDock ;
	__property OnStartDock ;
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCCListBox(HWND ParentWindow) : Controls::TCustomControl(
		ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Cclistbox */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Cclistbox;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCListBox
