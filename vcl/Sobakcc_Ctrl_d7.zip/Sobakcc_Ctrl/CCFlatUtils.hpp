// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCFlatUtils.pas' rev: 5.00

#ifndef CCFlatUtilsHPP
#define CCFlatUtilsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <CCHSLUtils.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ccflatutils
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TScrollType { up, down };
#pragma option pop

#pragma option push -b-
enum TColorCalcType { lighten, darken };
#pragma option pop

#pragma option push -b-
enum TCheckBoxLayout { checkboxLeft, checkboxRight };
#pragma option pop

#pragma option push -b-
enum TRadioButtonLayout { radioLeft, radioRight };
#pragma option pop

#pragma option push -b-
enum TFlatTabPosition { tpTop, tpBottom };
#pragma option pop

#pragma option push -b-
enum TArrowPos { NE, NW, SE, SW };
#pragma option pop

typedef Shortint TNumGlyphs;

typedef Shortint TAdvColors;

#pragma option push -b-
enum TGroupBoxBorder { brFull, brOnlyTopLine };
#pragma option pop

#pragma option push -b-
enum TTransparentMode { tmAlways, tmNotFocused, tmNone };
#pragma option pop

//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall DrawParentImage(Controls::TControl* Control, Graphics::TCanvas* Dest)
	;
extern PACKAGE Graphics::TBitmap* __fastcall CreateDisabledBitmap(Graphics::TBitmap* FOriginal, Graphics::TColor 
	OutlineColor, Graphics::TColor BackColor, Graphics::TColor HighlightColor, Graphics::TColor ShadowColor
	, bool DrawHighlight);
extern PACKAGE Graphics::TColor __fastcall CalcAdvancedColor(Graphics::TColor ParentColor, Graphics::TColor 
	OriginalColor, Byte Percent, TColorCalcType ColorType);
extern PACKAGE void __fastcall CalcButtonLayout(Graphics::TCanvas* Canvas, const Windows::TRect &Client
	, const Windows::TPoint &Offset, Buttons::TButtonLayout Layout, int Spacing, int Margin, Graphics::TBitmap* 
	FGlyph, int FNumGlyphs, const AnsiString Caption, Windows::TRect &TextBounds, Windows::TPoint &GlyphPos
	);
extern PACKAGE Word __fastcall Min(Word val1, Word val2);
extern PACKAGE tagTEXTMETRICA __fastcall GetFontMetrics(Graphics::TFont* Font);
extern PACKAGE int __fastcall GetFontHeight(Graphics::TFont* Font);
extern PACKAGE bool __fastcall RectInRect(const Windows::TRect &R1, const Windows::TRect &R2);

}	/* namespace Ccflatutils */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Ccflatutils;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCFlatUtils
