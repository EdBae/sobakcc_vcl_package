// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCFlatGraphics.pas' rev: 5.00

#ifndef CCFlatGraphicsHPP
#define CCFlatGraphicsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Forms.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ccflatgraphics
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
static const Graphics::TColor ecDarkBlue = 0x996633;
static const Graphics::TColor ecBlue = 0xcf9030;
static const Graphics::TColor ecLightBlue = 0xcfb78f;
static const Graphics::TColor ecDarkRed = 0x302794;
static const Graphics::TColor ecRed = 0x5f58b0;
static const Graphics::TColor ecLightRed = 0x6963b6;
static const Graphics::TColor ecDarkGreen = 0x385937;
static const Graphics::TColor ecGreen = 0x518150;
static const Graphics::TColor ecLightGreen = 0x93cab1;
static const Graphics::TColor ecDarkYellow = 0x4eb6cf;
static const Graphics::TColor ecYellow = 0x57d1ff;
static const Graphics::TColor ecLightYellow = 0xb3f8ff;
static const Graphics::TColor ecDarkBrown = 0x394d4d;
static const Graphics::TColor ecBrown = 0x555e66;
static const Graphics::TColor ecLightBrown = 0x829aa2;
static const Graphics::TColor ecDarkKaki = 0xd3d3d3;
static const Graphics::TColor ecKaki = 0xc8d7d7;
static const Graphics::TColor ecLightKaki = 0xe0e9ef;
static const int ecBtnHighlight = 0xffffff;
static const int ecBtnShadow = 0x0;
static const Graphics::TColor ecBtnFace = 0xe0e9ef;
static const Graphics::TColor ecBtnFaceDown = 0xc8d7d7;
static const int ecFocused = 0xffffff;
static const Graphics::TColor ecScrollbar = 0xe0e9ef;
static const Graphics::TColor ecScrollbarThumb = 0x829aa2;
static const int ecBackground = 0xffffff;
static const Graphics::TColor ecHint = 0x57d1ff;
static const int ecHintArrow = 0x0;
static const int ecDot = 0x0;
static const int ecTick = 0x0;
static const Graphics::TColor ecMenuBorder = 0x394d4d;
static const int ecMenu = 0x0;
static const Graphics::TColor ecMenuSelected = 0x4eb6cf;
static const Graphics::TColor ecProgressBlock = 0xcf9030;
static const Graphics::TColor ecUnselectedTab = 0xcf9030;
static const int ecSelection = 0x800000;
static const int ecCaption = 0x0;
static const int ecCaptionText = 0xffffff;

}	/* namespace Ccflatgraphics */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Ccflatgraphics;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCFlatGraphics
