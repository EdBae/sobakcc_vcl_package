// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCHSLUtils.pas' rev: 5.00

#ifndef CCHSLUtilsHPP
#define CCHSLUtilsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Graphics.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Cchslutils
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE int HSLRange;
extern PACKAGE Graphics::TColor __fastcall HSLtoRGB(double H, double S, double L);
extern PACKAGE Graphics::TColor __fastcall HSLRangeToRGB(int H, int S, int L);
extern PACKAGE void __fastcall RGBtoHSL(Graphics::TColor RGB, double &H, double &S, double &L);
extern PACKAGE void __fastcall RGBtoHSLRange(Graphics::TColor RGB, int &H, int &S, int &L);

}	/* namespace Cchslutils */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Cchslutils;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCHSLUtils
