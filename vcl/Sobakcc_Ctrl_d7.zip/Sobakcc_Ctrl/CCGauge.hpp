// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCGauge.pas' rev: 5.00

#ifndef CCGaugeHPP
#define CCGaugeHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <CCFlatUtils.hpp>	// Pascal unit
#include <Consts.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ccgauge
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCCGauge;
class PASCALIMPLEMENTATION TCCGauge : public Controls::TGraphicControl 
{
	typedef Controls::TGraphicControl inherited;
	
private:
	bool FTransparent;
	bool FUseAdvColors;
	Ccflatutils::TAdvColors FAdvColorBorder;
	Graphics::TColor FBarColor;
	Graphics::TColor FBorderColor;
	int FMinValue;
	int FMaxValue;
	int FProgress;
	bool FShowText;
	void __fastcall SetShowText(bool Value);
	void __fastcall SetMinValue(int Value);
	void __fastcall SetMaxValue(int Value);
	void __fastcall SetProgress(int Value);
	void __fastcall SetColors(int Index, Graphics::TColor Value);
	void __fastcall SetAdvColors(int Index, Ccflatutils::TAdvColors Value);
	void __fastcall SetUseAdvColors(bool Value);
	MESSAGE void __fastcall CMSysColorChange(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMParentColorChanged(Messages::TWMNoParams &Message);
	void __fastcall SetTransparent(const bool Value);
	
protected:
	void __fastcall CalcAdvColors(void);
	virtual void __fastcall Paint(void);
	
public:
	__fastcall virtual TCCGauge(Classes::TComponent* AOwner);
	
__published:
	__property Ccflatutils::TAdvColors AdvColorBorder = {read=FAdvColorBorder, write=SetAdvColors, index=0
		, default=50};
	__property bool Transparent = {read=FTransparent, write=SetTransparent, default=0};
	__property bool UseAdvColors = {read=FUseAdvColors, write=SetUseAdvColors, default=0};
	__property Color ;
	__property Graphics::TColor ColorBorder = {read=FBorderColor, write=SetColors, index=0, default=5594726
		};
	__property Graphics::TColor BarColor = {read=FBarColor, write=SetColors, index=1, default=10053171}
		;
	__property int MinValue = {read=FMinValue, write=SetMinValue, default=0};
	__property int MaxValue = {read=FMaxValue, write=SetMaxValue, default=100};
	__property int Progress = {read=FProgress, write=SetProgress, nodefault};
	__property bool ShowText = {read=FShowText, write=SetShowText, default=1};
	__property Align ;
	__property Enabled ;
	__property Font ;
	__property ParentColor ;
	__property ParentFont ;
	__property ParentShowHint ;
	__property ShowHint ;
	__property Visible ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnEndDrag ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property OnStartDrag ;
	__property Anchors ;
	__property BiDiMode ;
	__property Constraints ;
	__property DragKind ;
	__property ParentBiDiMode ;
	__property OnEndDock ;
	__property OnStartDock ;
public:
	#pragma option push -w-inl
	/* TGraphicControl.Destroy */ inline __fastcall virtual ~TCCGauge(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Ccgauge */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Ccgauge;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCGauge
