// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCPanel.pas' rev: 5.00

#ifndef CCPanelHPP
#define CCPanelHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Menus.hpp>	// Pascal unit
#include <CCFlatUtils.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ccpanel
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCCPanel;
class PASCALIMPLEMENTATION TCCPanel : public Extctrls::TCustomPanel 
{
	typedef Extctrls::TCustomPanel inherited;
	
private:
	bool FTransparent;
	Graphics::TColor FColorHighlight;
	Graphics::TColor FColorShadow;
	void __fastcall SetColors(int Index, Graphics::TColor Value);
	HIDESBASE MESSAGE void __fastcall CMEnabledChanged(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMTextChanged(Messages::TWMNoParams &Message);
	void __fastcall SetTransparent(const bool Value);
	
protected:
	virtual void __fastcall Paint(void);
	
public:
	__fastcall virtual TCCPanel(Classes::TComponent* AOwner);
	
__published:
	__property bool Transparent = {read=FTransparent, write=SetTransparent, default=0};
	__property Caption ;
	__property Font ;
	__property Color ;
	__property ParentColor ;
	__property Enabled ;
	__property Visible ;
	__property Graphics::TColor ColorHighLight = {read=FColorHighlight, write=SetColors, index=0, default=8623776
		};
	__property Graphics::TColor ColorShadow = {read=FColorShadow, write=SetColors, index=1, default=8623776
		};
	__property Align ;
	__property Alignment ;
	__property Cursor ;
	__property Hint ;
	__property ParentShowHint ;
	__property ShowHint ;
	__property PopupMenu ;
	__property TabOrder ;
	__property TabStop ;
	__property AutoSize ;
	__property UseDockManager ;
	__property Anchors ;
	__property BiDiMode ;
	__property Constraints ;
	__property DragKind ;
	__property DragMode ;
	__property DragCursor ;
	__property ParentBiDiMode ;
	__property DockSite ;
	__property OnEndDock ;
	__property OnStartDock ;
	__property OnCanResize ;
	__property OnConstrainedResize ;
	__property OnDockDrop ;
	__property OnDockOver ;
	__property OnGetSiteInfo ;
	__property OnUnDock ;
	__property OnContextPopup ;
	__property OnClick ;
	__property OnDblClick ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnEndDrag ;
	__property OnEnter ;
	__property OnExit ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property OnResize ;
	__property OnStartDrag ;
public:
	#pragma option push -w-inl
	/* TCustomControl.Destroy */ inline __fastcall virtual ~TCCPanel(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCCPanel(HWND ParentWindow) : Extctrls::TCustomPanel(
		ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Ccpanel */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Ccpanel;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCPanel
