// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCSplitter.pas' rev: 5.00

#ifndef CCSplitterHPP
#define CCSplitterHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <CCFlatUtils.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ccsplitter
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TSplitterStatus { ssIn, ssOut };
#pragma option pop

class DELPHICLASS THack;
class PASCALIMPLEMENTATION THack : public Controls::TWinControl 
{
	typedef Controls::TWinControl inherited;
	
public:
	#pragma option push -w-inl
	/* TWinControl.Create */ inline __fastcall virtual THack(Classes::TComponent* AOwner) : Controls::TWinControl(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall THack(HWND ParentWindow) : Controls::TWinControl(
		ParentWindow) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TWinControl.Destroy */ inline __fastcall virtual ~THack(void) { }
	#pragma option pop
	
};


class DELPHICLASS TCCSplitter;
class PASCALIMPLEMENTATION TCCSplitter : public Controls::TGraphicControl 
{
	typedef Controls::TGraphicControl inherited;
	
private:
	bool FUseAdvColors;
	Ccflatutils::TAdvColors FAdvColorBorder;
	Ccflatutils::TAdvColors FAdvColorFocused;
	Graphics::TColor FBorderColor;
	Graphics::TColor FFocusedColor;
	HDC FLineDC;
	Windows::TPoint FDownPos;
	int FSplit;
	Extctrls::NaturalNumber FMinSize;
	int FMaxSize;
	Controls::TControl* FControl;
	int FNewSize;
	Controls::TWinControl* FActiveControl;
	Controls::TKeyEvent FOldKeyDown;
	bool FLineVisible;
	Classes::TNotifyEvent FOnMoved;
	TSplitterStatus FStatus;
	void __fastcall AllocateLineDC(void);
	void __fastcall DrawLine(void);
	void __fastcall ReleaseLineDC(void);
	void __fastcall UpdateSize(int X, int Y);
	void __fastcall FocusKeyDown(System::TObject* Sender, Word &Key, Classes::TShiftState Shift);
	void __fastcall SetColors(int Index, Graphics::TColor Value);
	void __fastcall SetAdvColors(int Index, Ccflatutils::TAdvColors Value);
	void __fastcall SetUseAdvColors(bool Value);
	MESSAGE void __fastcall CMSysColorChange(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMParentColorChanged(Messages::TWMNoParams &Message);
	MESSAGE void __fastcall CMEnter(Messages::TMessage &Message);
	MESSAGE void __fastcall CMExit(Messages::TMessage &Message);
	
protected:
	void __fastcall CalcAdvColors(void);
	virtual void __fastcall Paint(void);
	DYNAMIC void __fastcall MouseDown(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, 
		int Y);
	DYNAMIC void __fastcall MouseMove(Classes::TShiftState Shift, int X, int Y);
	DYNAMIC void __fastcall MouseUp(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int 
		Y);
	void __fastcall StopSizing(void);
	
public:
	__fastcall virtual TCCSplitter(Classes::TComponent* AOwner);
	
__published:
	__property Ccflatutils::TAdvColors AdvColorBorder = {read=FAdvColorBorder, write=SetAdvColors, index=0
		, default=50};
	__property Ccflatutils::TAdvColors AdvColorFocused = {read=FAdvColorFocused, write=SetAdvColors, index=1
		, default=50};
	__property bool UseAdvColors = {read=FUseAdvColors, write=SetUseAdvColors, default=0};
	__property Color ;
	__property Graphics::TColor ColorFocused = {read=FFocusedColor, write=SetColors, index=0, default=5493503
		};
	__property Graphics::TColor ColorBorder = {read=FBorderColor, write=SetColors, index=1, default=5594726
		};
	__property Extctrls::NaturalNumber MinSize = {read=FMinSize, write=FMinSize, default=30};
	__property Classes::TNotifyEvent OnMoved = {read=FOnMoved, write=FOnMoved};
	__property Align ;
	__property Enabled ;
	__property ParentColor ;
	__property ParentShowHint ;
	__property ShowHint ;
	__property Visible ;
	__property Anchors ;
	__property BiDiMode ;
	__property Constraints ;
	__property ParentBiDiMode ;
public:
	#pragma option push -w-inl
	/* TGraphicControl.Destroy */ inline __fastcall virtual ~TCCSplitter(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Ccsplitter */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Ccsplitter;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCSplitter
