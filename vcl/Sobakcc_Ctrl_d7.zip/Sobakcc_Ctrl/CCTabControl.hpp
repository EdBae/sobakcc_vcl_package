// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCTabControl.pas' rev: 5.00

#ifndef CCTabControlHPP
#define CCTabControlHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <CCFlatUtils.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Cctabcontrol
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCCTabControl;
class PASCALIMPLEMENTATION TCCTabControl : public Controls::TCustomControl 
{
	typedef Controls::TCustomControl inherited;
	
private:
	bool FUseAdvColors;
	Ccflatutils::TAdvColors FAdvColorBorder;
	Ccflatutils::TFlatTabPosition FTabPosition;
	Classes::TStrings* FTabs;
	Classes::TList* FTabsRect;
	int FTabHeight;
	int FTabSpacing;
	int FActiveTab;
	Graphics::TColor FUnselectedColor;
	Graphics::TColor FBorderColor;
	Classes::TNotifyEvent FOnTabChanged;
	void __fastcall SetTabs(Classes::TStrings* Value);
	void __fastcall SetTabPosition(Ccflatutils::TFlatTabPosition Value);
	void __fastcall SetTabHeight(int Value);
	void __fastcall SetTabSpacing(int Value);
	void __fastcall SetActiveTab(int Value);
	void __fastcall SetColors(int Index, Graphics::TColor Value);
	void __fastcall SetAdvColors(int Index, Ccflatutils::TAdvColors Value);
	void __fastcall SetUseAdvColors(bool Value);
	void __fastcall SetTabRect(void);
	HIDESBASE MESSAGE void __fastcall CMDialogChar(Messages::TWMKey &Message);
	HIDESBASE MESSAGE void __fastcall CMEnabledChanged(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall WMSize(Messages::TWMSize &Message);
	HIDESBASE MESSAGE void __fastcall CMSysColorChange(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMParentColorChanged(Messages::TWMNoParams &Message);
	HIDESBASE MESSAGE void __fastcall CMDesignHitTest(Messages::TWMMouse &Message);
	HIDESBASE MESSAGE void __fastcall CMCHANGED(Controls::TCMChanged &Message);
	HIDESBASE MESSAGE void __fastcall WMMove(Messages::TWMMove &Message);
	
protected:
	void __fastcall CalcAdvColors(void);
	DYNAMIC void __fastcall MouseDown(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, 
		int Y);
	virtual void __fastcall Loaded(void);
	virtual void __fastcall Paint(void);
	virtual void __fastcall AlignControls(Controls::TControl* AControl, Windows::TRect &Rect);
	
public:
	__fastcall virtual TCCTabControl(Classes::TComponent* AOwner);
	__fastcall virtual ~TCCTabControl(void);
	
__published:
	__property Align ;
	__property Graphics::TColor ColorBorder = {read=FBorderColor, write=SetColors, index=0, default=8623776
		};
	__property Graphics::TColor ColorUnselectedTab = {read=FUnselectedColor, write=SetColors, index=1, 
		default=10053171};
	__property Ccflatutils::TAdvColors AdvColorBorder = {read=FAdvColorBorder, write=SetAdvColors, index=0
		, default=50};
	__property bool UseAdvColors = {read=FUseAdvColors, write=SetUseAdvColors, default=0};
	__property Classes::TStrings* Tabs = {read=FTabs, write=SetTabs};
	__property int TabHeight = {read=FTabHeight, write=SetTabHeight, default=16};
	__property int TabSpacing = {read=FTabSpacing, write=SetTabSpacing, default=4};
	__property Ccflatutils::TFlatTabPosition TabPosition = {read=FTabPosition, write=SetTabPosition, default=0
		};
	__property int ActiveTab = {read=FActiveTab, write=SetActiveTab, default=0};
	__property Font ;
	__property Color ;
	__property ParentColor ;
	__property Enabled ;
	__property Visible ;
	__property Cursor ;
	__property ParentShowHint ;
	__property ParentFont ;
	__property ShowHint ;
	__property TabOrder ;
	__property TabStop ;
	__property OnEnter ;
	__property OnExit ;
	__property OnMouseMove ;
	__property OnMouseDown ;
	__property OnMouseUp ;
	__property Classes::TNotifyEvent OnTabChanged = {read=FOnTabChanged, write=FOnTabChanged};
	__property Anchors ;
	__property BiDiMode ;
	__property Constraints ;
	__property DragKind ;
	__property ParentBiDiMode ;
	__property OnEndDock ;
	__property OnStartDock ;
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCCTabControl(HWND ParentWindow) : Controls::TCustomControl(
		ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Cctabcontrol */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Cctabcontrol;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCTabControl
