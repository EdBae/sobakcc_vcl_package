// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCHint.pas' rev: 5.00

#ifndef CCHintHPP
#define CCHintHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <CCFlatUtils.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Cchint
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCCHint;
class PASCALIMPLEMENTATION TCCHint : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	Graphics::TFont* FHintFont;
	Graphics::TColor FBackgroundColor;
	Graphics::TColor FBorderColor;
	Graphics::TColor FArrowBackgroundColor;
	Graphics::TColor FArrowColor;
	HWND FWindowHandle;
	int FHintWidth;
	Forms::TShowHintEvent FOnShowHint;
	void __fastcall SetColors(int Index, Graphics::TColor Value);
	void __fastcall SetHintFont(Graphics::TFont* Value);
	void __fastcall GetHintInfo(AnsiString &HintStr, bool &CanShow, Forms::THintInfo &HintInfo);
	
public:
	__fastcall virtual TCCHint(Classes::TComponent* AOwner);
	__fastcall virtual ~TCCHint(void);
	
__published:
	__property Graphics::TColor ColorBackground = {read=FBackgroundColor, write=SetColors, index=0, default=16777215
		};
	__property Graphics::TColor ColorBorder = {read=FBorderColor, write=SetColors, index=1, default=0};
		
	__property Graphics::TColor ColorArrowBackground = {read=FArrowBackgroundColor, write=SetColors, index=2
		, default=5493503};
	__property Graphics::TColor ColorArrow = {read=FArrowColor, write=SetColors, index=3, default=0};
	__property int MaxHintWidth = {read=FHintWidth, write=FHintWidth, default=200};
	__property Graphics::TFont* Font = {read=FHintFont, write=SetHintFont};
	__property Forms::TShowHintEvent OnShowHint = {read=FOnShowHint, write=FOnShowHint};
};


class DELPHICLASS TCCHintWindow;
class PASCALIMPLEMENTATION TCCHintWindow : public Controls::THintWindow 
{
	typedef Controls::THintWindow inherited;
	
private:
	Ccflatutils::TArrowPos FArrowPos;
	Windows::TPoint FArrowPoint;
	TCCHint* FHint;
	TCCHint* __fastcall FindFlatHint(void);
	
protected:
	virtual void __fastcall Paint(void);
	virtual void __fastcall CreateParams(Controls::TCreateParams &Params);
	
public:
	virtual void __fastcall ActivateHint(const Windows::TRect &HintRect, const AnsiString AHint);
public:
		
	#pragma option push -w-inl
	/* THintWindow.Create */ inline __fastcall virtual TCCHintWindow(Classes::TComponent* AOwner) : Controls::THintWindow(
		AOwner) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TCustomControl.Destroy */ inline __fastcall virtual ~TCCHintWindow(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCCHintWindow(HWND ParentWindow) : Controls::THintWindow(
		ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Cchint */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Cchint;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCHint
