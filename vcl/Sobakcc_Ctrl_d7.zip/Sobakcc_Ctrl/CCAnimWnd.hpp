// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCAnimWnd.pas' rev: 5.00

#ifndef CCAnimWndHPP
#define CCAnimWndHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ccanimwnd
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCCAnimHookWnd;
class DELPHICLASS TCCAnimWnd;
class PASCALIMPLEMENTATION TCCAnimWnd : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	Classes::TComponent* FOwner;
	void *FNewProc;
	void *FOldProc;
	void *FNewAppProc;
	void *FOldAppProc;
	Classes::TNotifyEvent FOnMinimize;
	Classes::TNotifyEvent FOnRestore;
	void __fastcall NewWndProc(Messages::TMessage &Message);
	void __fastcall NewAppWndProc(Messages::TMessage &Message);
	void __fastcall MinimizeWnd(void);
	void __fastcall RestoreWnd(void);
	void __fastcall OwnerWndCreated(void);
	void __fastcall OwnerWndDestroyed(void);
	
protected:
	TCCAnimHookWnd* FHookWnd;
	DYNAMIC void __fastcall SetParentComponent(Classes::TComponent* Value);
	
public:
	__fastcall virtual TCCAnimWnd(Classes::TComponent* AOwner);
	__fastcall virtual ~TCCAnimWnd(void);
	void __fastcall Minimize(void);
	
__published:
	__property Classes::TNotifyEvent OnMinimize = {read=FOnMinimize, write=FOnMinimize};
	__property Classes::TNotifyEvent OnRestore = {read=FOnRestore, write=FOnRestore};
};


class PASCALIMPLEMENTATION TCCAnimHookWnd : public Controls::TWinControl 
{
	typedef Controls::TWinControl inherited;
	
private:
	TCCAnimWnd* FAnimateWindow;
	MESSAGE void __fastcall WMCreate(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall WMDestroy(Messages::TMessage &Message);
	
public:
	__fastcall virtual TCCAnimHookWnd(Classes::TComponent* AOwner);
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCCAnimHookWnd(HWND ParentWindow) : Controls::TWinControl(
		ParentWindow) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TWinControl.Destroy */ inline __fastcall virtual ~TCCAnimHookWnd(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Ccanimwnd */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Ccanimwnd;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCAnimWnd
