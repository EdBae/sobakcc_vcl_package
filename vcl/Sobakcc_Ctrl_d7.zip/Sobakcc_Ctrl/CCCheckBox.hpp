// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCCheckBox.pas' rev: 5.00

#ifndef CCCheckBoxHPP
#define CCCheckBoxHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <CCFlatUtils.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Cccheckbox
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCCCheckBox;
class PASCALIMPLEMENTATION TCCCheckBox : public Controls::TCustomControl 
{
	typedef Controls::TCustomControl inherited;
	
private:
	bool FUseAdvColors;
	Ccflatutils::TAdvColors FAdvColorFocused;
	Ccflatutils::TAdvColors FAdvColorDown;
	Ccflatutils::TAdvColors FAdvColorBorder;
	bool FMouseInControl;
	bool MouseIsDown;
	bool Focused;
	Ccflatutils::TCheckBoxLayout FLayout;
	bool FChecked;
	Graphics::TColor FFocusedColor;
	Graphics::TColor FDownColor;
	Graphics::TColor FCheckColor;
	Graphics::TColor FBorderColor;
	bool FTransparent;
	void __fastcall SetColors(int Index, Graphics::TColor Value);
	void __fastcall SetAdvColors(int Index, Ccflatutils::TAdvColors Value);
	void __fastcall SetUseAdvColors(bool Value);
	void __fastcall SetLayout(Ccflatutils::TCheckBoxLayout Value);
	void __fastcall SetChecked(bool Value);
	void __fastcall SetTransparent(const bool Value);
	HIDESBASE MESSAGE void __fastcall CMEnabledChanged(Messages::TMessage &Message);
	MESSAGE void __fastcall CMTextChanged(Messages::TWMNoParams &Message);
	HIDESBASE MESSAGE void __fastcall CMDialogChar(Messages::TWMKey &Message);
	MESSAGE void __fastcall CNCommand(Messages::TWMCommand &Message);
	HIDESBASE MESSAGE void __fastcall WMSetFocus(Messages::TWMSetFocus &Message);
	HIDESBASE MESSAGE void __fastcall WMKillFocus(Messages::TWMKillFocus &Message);
	HIDESBASE MESSAGE void __fastcall CMSysColorChange(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMParentColorChanged(Messages::TWMNoParams &Message);
	void __fastcall RemoveMouseTimer(void);
	void __fastcall MouseTimerHandler(System::TObject* Sender);
	HIDESBASE MESSAGE void __fastcall CMDesignHitTest(Messages::TWMMouse &Message);
	HIDESBASE MESSAGE void __fastcall WMSize(Messages::TWMSize &Message);
	HIDESBASE MESSAGE void __fastcall WMMove(Messages::TWMMove &Message);
	
protected:
	void __fastcall CalcAdvColors(void);
	DYNAMIC void __fastcall DoEnter(void);
	DYNAMIC void __fastcall DoExit(void);
	DYNAMIC void __fastcall MouseDown(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, 
		int Y);
	DYNAMIC void __fastcall MouseUp(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int 
		Y);
	DYNAMIC void __fastcall MouseMove(Classes::TShiftState Shift, int X, int Y);
	virtual void __fastcall CreateWnd(void);
	void __fastcall DrawCheckRect(void);
	void __fastcall DrawCheckText(void);
	virtual void __fastcall Paint(void);
	
public:
	__fastcall virtual TCCCheckBox(Classes::TComponent* AOwner);
	__fastcall virtual ~TCCCheckBox(void);
	void __fastcall MouseEnter(void);
	void __fastcall MouseLeave(void);
	
__published:
	__property bool Transparent = {read=FTransparent, write=SetTransparent, default=0};
	__property Caption ;
	__property bool Checked = {read=FChecked, write=SetChecked, default=0};
	__property Color ;
	__property Graphics::TColor ColorFocused = {read=FFocusedColor, write=SetColors, index=0, default=16777215
		};
	__property Graphics::TColor ColorDown = {read=FDownColor, write=SetColors, index=1, default=12965593
		};
	__property Graphics::TColor ColorCheck = {read=FCheckColor, write=SetColors, index=2, default=0};
	__property Graphics::TColor ColorBorder = {read=FBorderColor, write=SetColors, index=3, default=8623776
		};
	__property Ccflatutils::TAdvColors AdvColorFocused = {read=FAdvColorFocused, write=SetAdvColors, index=0
		, default=10};
	__property Ccflatutils::TAdvColors AdvColorDown = {read=FAdvColorDown, write=SetAdvColors, index=1, 
		default=10};
	__property Ccflatutils::TAdvColors AdvColorBorder = {read=FAdvColorBorder, write=SetAdvColors, index=2
		, default=50};
	__property bool UseAdvColors = {read=FUseAdvColors, write=SetUseAdvColors, default=0};
	__property Enabled ;
	__property Font ;
	__property Ccflatutils::TCheckBoxLayout Layout = {read=FLayout, write=SetLayout, default=0};
	__property ParentColor ;
	__property ParentFont ;
	__property ShowHint ;
	__property TabOrder ;
	__property TabStop ;
	__property Visible ;
	__property OnClick ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnEndDrag ;
	__property OnEnter ;
	__property OnExit ;
	__property OnKeyDown ;
	__property OnKeyPress ;
	__property OnKeyUp ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property Action ;
	__property Anchors ;
	__property BiDiMode ;
	__property Constraints ;
	__property DragKind ;
	__property ParentBiDiMode ;
	__property OnEndDock ;
	__property OnStartDock ;
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCCCheckBox(HWND ParentWindow) : Controls::TCustomControl(
		ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TCCCheckBox* MouseInControl;

}	/* namespace Cccheckbox */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Cccheckbox;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCCheckBox
