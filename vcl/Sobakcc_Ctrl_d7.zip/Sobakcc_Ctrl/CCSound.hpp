// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCSound.pas' rev: 5.00

#ifndef CCSoundHPP
#define CCSoundHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <MMSystem.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ccsound
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TSoundEvent { seBtnClick, seMenu, seMenuClick, seMoveIntoBtn, sePanelExpand };
#pragma option pop

class DELPHICLASS TCCSound;
class PASCALIMPLEMENTATION TCCSound : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	TSoundEvent FEvent;
	
public:
	void __fastcall Play(void);
	void __fastcall PlayThis(TSoundEvent ThisEvent);
	__fastcall virtual TCCSound(Classes::TComponent* AOwner);
	
__published:
	__property TSoundEvent Event = {read=FEvent, write=FEvent, nodefault};
public:
	#pragma option push -w-inl
	/* TComponent.Destroy */ inline __fastcall virtual ~TCCSound(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
static const int Flags = 0x40004;

}	/* namespace Ccsound */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Ccsound;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCSound
