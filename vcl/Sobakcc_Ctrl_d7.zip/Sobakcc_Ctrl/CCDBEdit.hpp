// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCDBEdit.pas' rev: 5.00

#ifndef CCDBEditHPP
#define CCDBEditHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Menus.hpp>	// Pascal unit
#include <DBCtrls.hpp>	// Pascal unit
#include <Mask.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ccdbedit
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCCDBEdit;
class PASCALIMPLEMENTATION TCCDBEdit : public Dbctrls::TDBEdit 
{
	typedef Dbctrls::TDBEdit inherited;
	
private:
	bool FParentColor;
	Graphics::TColor FFocusedColor;
	Graphics::TColor FBorderColor;
	Graphics::TColor FFlatColor;
	bool MouseInControl;
	void __fastcall SetColors(int Index, Graphics::TColor Value);
	HIDESBASE void __fastcall SetParentColor(bool Value);
	void __fastcall RedrawBorder(const HRGN Clip);
	void __fastcall NewAdjustHeight(void);
	HIDESBASE MESSAGE void __fastcall CMEnabledChanged(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMFontChanged(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMMouseEnter(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMMouseLeave(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall WMSetFocus(Messages::TWMSetFocus &Message);
	HIDESBASE MESSAGE void __fastcall WMKillFocus(Messages::TWMKillFocus &Message);
	HIDESBASE MESSAGE void __fastcall WMNCCalcSize(Messages::TWMNCCalcSize &Message);
	HIDESBASE MESSAGE void __fastcall WMNCPaint(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMSysColorChange(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMParentColorChanged(Messages::TWMNoParams &Message);
	
__published:
	virtual void __fastcall Loaded(void);
	__property Graphics::TColor ColorFocused = {read=FFocusedColor, write=SetColors, index=0, default=16777215
		};
	__property Graphics::TColor ColorBorder = {read=FBorderColor, write=SetColors, index=1, default=8623776
		};
	__property Graphics::TColor ColorFlat = {read=FFlatColor, write=SetColors, index=2, default=14805739
		};
	__property bool ParentColor = {read=FParentColor, write=SetParentColor, default=0};
	__property CharCase ;
	__property DragCursor ;
	__property DragMode ;
	__property Enabled ;
	__property Font ;
	__property HideSelection ;
	__property MaxLength ;
	__property OEMConvert ;
	__property ParentFont ;
	__property ParentShowHint ;
	__property PasswordChar ;
	__property PopupMenu ;
	__property ReadOnly ;
	__property ShowHint ;
	__property TabOrder ;
	__property TabStop ;
	__property Text ;
	__property Visible ;
	__property OnChange ;
	__property OnClick ;
	__property OnDblClick ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnEndDrag ;
	__property OnEnter ;
	__property OnExit ;
	__property OnKeyDown ;
	__property OnKeyPress ;
	__property OnKeyUp ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property OnStartDrag ;
	__property Anchors ;
	__property BiDiMode ;
	__property Constraints ;
	__property DragKind ;
	__property ParentBiDiMode ;
	__property OnEndDock ;
	__property OnStartDock ;
	
public:
	__fastcall virtual TCCDBEdit(Classes::TComponent* AOwner);
public:
	#pragma option push -w-inl
	/* TDBEdit.Destroy */ inline __fastcall virtual ~TCCDBEdit(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCCDBEdit(HWND ParentWindow) : Dbctrls::TDBEdit(
		ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Ccdbedit */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Ccdbedit;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCDBEdit
