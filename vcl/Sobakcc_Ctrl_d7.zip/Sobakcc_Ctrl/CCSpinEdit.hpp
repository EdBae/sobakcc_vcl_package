// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'CCSpinEdit.pas' rev: 5.00

#ifndef CCSpinEditHPP
#define CCSpinEditHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Menus.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <CCSpinButton.hpp>	// Pascal unit
#include <CCEdit.hpp>	// Pascal unit
#include <CCFlatUtils.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ccspinedit
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCCSpinEditInteger;
class PASCALIMPLEMENTATION TCCSpinEditInteger : public Ccedit::TCCCustomEdit 
{
	typedef Ccedit::TCCCustomEdit inherited;
	
private:
	int FMinValue;
	int FMaxValue;
	int FIncrement;
	Ccspinbutton::TCCSpinButton* FButton;
	bool FEditorEnabled;
	int __fastcall GetMinHeight(void);
	int __fastcall GetValue(void);
	int __fastcall CheckValue(int NewValue);
	void __fastcall SetValue(int NewValue);
	void __fastcall SetEditRect(void);
	HIDESBASE MESSAGE void __fastcall WMSize(Messages::TWMSize &Message);
	HIDESBASE MESSAGE void __fastcall CMEnter(Messages::TWMNoParams &Message);
	HIDESBASE MESSAGE void __fastcall CMExit(Messages::TWMNoParams &Message);
	MESSAGE void __fastcall WMPaste(Messages::TWMNoParams &Message);
	MESSAGE void __fastcall WMCut(Messages::TWMNoParams &Message);
	
protected:
	DYNAMIC void __fastcall GetChildren(Classes::TGetChildProc Proc, Classes::TComponent* Root);
	virtual bool __fastcall IsValidChar(char Key);
	virtual void __fastcall UpClick(System::TObject* Sender);
	virtual void __fastcall DownClick(System::TObject* Sender);
	DYNAMIC void __fastcall KeyDown(Word &Key, Classes::TShiftState Shift);
	DYNAMIC void __fastcall KeyPress(char &Key);
	virtual void __fastcall CreateParams(Controls::TCreateParams &Params);
	virtual void __fastcall Loaded(void);
	virtual void __fastcall CreateWnd(void);
	
public:
	__fastcall virtual TCCSpinEditInteger(Classes::TComponent* AOwner);
	__fastcall virtual ~TCCSpinEditInteger(void);
	__property Ccspinbutton::TCCSpinButton* Button = {read=FButton};
	
__published:
	__property ColorFocused ;
	__property ColorBorder ;
	__property ColorFlat ;
	__property AdvColorFocused ;
	__property AdvColorBorder ;
	__property UseAdvColors ;
	__property AutoSelect ;
	__property AutoSize ;
	__property DragCursor ;
	__property DragMode ;
	__property bool EditorEnabled = {read=FEditorEnabled, write=FEditorEnabled, default=1};
	__property Enabled ;
	__property Font ;
	__property int Increment = {read=FIncrement, write=FIncrement, default=1};
	__property int MaxValue = {read=FMaxValue, write=FMaxValue, nodefault};
	__property int MinValue = {read=FMinValue, write=FMinValue, nodefault};
	__property ParentColor ;
	__property ParentFont ;
	__property ParentShowHint ;
	__property PopupMenu ;
	__property ReadOnly ;
	__property ShowHint ;
	__property TabOrder ;
	__property TabStop ;
	__property int Value = {read=GetValue, write=SetValue, nodefault};
	__property Visible ;
	__property OnChange ;
	__property OnClick ;
	__property OnDblClick ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnEndDrag ;
	__property OnEnter ;
	__property OnExit ;
	__property OnKeyDown ;
	__property OnKeyPress ;
	__property OnKeyUp ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property OnStartDrag ;
	__property Anchors ;
	__property BiDiMode ;
	__property Constraints ;
	__property DragKind ;
	__property ParentBiDiMode ;
	__property OnEndDock ;
	__property OnStartDock ;
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCCSpinEditInteger(HWND ParentWindow) : Ccedit::TCCCustomEdit(
		ParentWindow) { }
	#pragma option pop
	
};


class DELPHICLASS TCCSpinEditFloat;
class PASCALIMPLEMENTATION TCCSpinEditFloat : public Ccedit::TCCCustomEdit 
{
	typedef Ccedit::TCCCustomEdit inherited;
	
private:
	int FPrecision;
	int FDigits;
	Sysutils::TFloatFormat FFloatFormat;
	Extended FMinValue;
	Extended FMaxValue;
	Extended FIncrement;
	Ccspinbutton::TCCSpinButton* FButton;
	bool FEditorEnabled;
	int __fastcall GetMinHeight(void);
	Extended __fastcall GetValue(void);
	Extended __fastcall CheckValue(Extended Value);
	void __fastcall SetValue(Extended Value);
	void __fastcall SetPrecision(int Value);
	void __fastcall SetDigits(int Value);
	void __fastcall SetFloatFormat(Sysutils::TFloatFormat Value);
	void __fastcall SetEditRect(void);
	HIDESBASE MESSAGE void __fastcall WMSize(Messages::TWMSize &Message);
	HIDESBASE MESSAGE void __fastcall CMEnter(Messages::TWMNoParams &Message);
	HIDESBASE MESSAGE void __fastcall CMExit(Messages::TWMNoParams &Message);
	MESSAGE void __fastcall WMPaste(Messages::TWMNoParams &Message);
	MESSAGE void __fastcall WMCut(Messages::TWMNoParams &Message);
	
protected:
	virtual bool __fastcall IsValidChar(char Key);
	virtual void __fastcall UpClick(System::TObject* Sender);
	virtual void __fastcall DownClick(System::TObject* Sender);
	DYNAMIC void __fastcall KeyDown(Word &Key, Classes::TShiftState Shift);
	DYNAMIC void __fastcall KeyPress(char &Key);
	virtual void __fastcall CreateParams(Controls::TCreateParams &Params);
	virtual void __fastcall Loaded(void);
	virtual void __fastcall CreateWnd(void);
	
public:
	__fastcall virtual TCCSpinEditFloat(Classes::TComponent* AOwner);
	__fastcall virtual ~TCCSpinEditFloat(void);
	__property Ccspinbutton::TCCSpinButton* Button = {read=FButton};
	
__published:
	__property ColorFocused ;
	__property ColorBorder ;
	__property ColorFlat ;
	__property AdvColorFocused ;
	__property AdvColorBorder ;
	__property UseAdvColors ;
	__property AutoSelect ;
	__property AutoSize ;
	__property DragCursor ;
	__property DragMode ;
	__property int Digits = {read=FDigits, write=SetDigits, nodefault};
	__property int Precision = {read=FPrecision, write=SetPrecision, nodefault};
	__property Sysutils::TFloatFormat FloatFormat = {read=FFloatFormat, write=SetFloatFormat, nodefault
		};
	__property bool EditorEnabled = {read=FEditorEnabled, write=FEditorEnabled, default=1};
	__property Enabled ;
	__property Font ;
	__property Extended Increment = {read=FIncrement, write=FIncrement};
	__property Extended MaxValue = {read=FMaxValue, write=FMaxValue};
	__property Extended MinValue = {read=FMinValue, write=FMinValue};
	__property ParentColor ;
	__property ParentFont ;
	__property ParentShowHint ;
	__property PopupMenu ;
	__property ReadOnly ;
	__property ShowHint ;
	__property TabOrder ;
	__property TabStop ;
	__property Extended Value = {read=GetValue, write=SetValue};
	__property Visible ;
	__property OnChange ;
	__property OnClick ;
	__property OnDblClick ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnEndDrag ;
	__property OnEnter ;
	__property OnExit ;
	__property OnKeyDown ;
	__property OnKeyPress ;
	__property OnKeyUp ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property OnStartDrag ;
	__property Anchors ;
	__property BiDiMode ;
	__property Constraints ;
	__property DragKind ;
	__property ParentBiDiMode ;
	__property OnEndDock ;
	__property OnStartDock ;
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCCSpinEditFloat(HWND ParentWindow) : Ccedit::TCCCustomEdit(
		ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Ccspinedit */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Ccspinedit;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CCSpinEdit
